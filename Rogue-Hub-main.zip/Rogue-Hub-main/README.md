# _Rogue Hub_
[YouTube Channel](https://www.youtube.com/channel/UC9R30r3RanVhs0CkPpFb8iA) · [Discord Server](https://discord.com/invite/uzXNguueug) · [Script](https://raw.githubusercontent.com/Kitzoon/Rogue-Hub/main/LOADSTRING.lua)
<br>
<br>
![Rogue Hub No-Scope Arcade Script](https://cdn.discordapp.com/attachments/1022560613341335682/1022911870052618310/unknown.png)
<br>
![Rogue Hub Slap Battles Script](https://cdn.discordapp.com/attachments/1022560613341335682/1022912565271068702/unknown.png)
<br>
<br>
**skids dont win, only use this github repo to learn B)**
